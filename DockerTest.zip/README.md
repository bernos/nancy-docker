nancy-docker
============

Example httplistener hosted nancy owin application in a docker container
